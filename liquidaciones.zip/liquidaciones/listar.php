<?php
require_once 'auth.php';
header('Content-Type: application/json');

if (!usuarioAutenticado()) {
    http_response_code(403);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

$usuario = $_SESSION['usuario'];
$ruta = __DIR__ . "/usuarios/$usuario/";
$archivos = glob($ruta . "*.zip");
$nombres = array_map('basename', $archivos);
echo json_encode($nombres);
?>