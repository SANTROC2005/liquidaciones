<?php
require_once 'auth.php';
header('Content-Type: application/json');

if (!usuarioAutenticado()) {
    http_response_code(403);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

$usuario = $_SESSION['usuario'];
$ruta = __DIR__ . "/usuarios/$usuario/";

if (!isset($_FILES['archivo']) || $_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['error' => 'Archivo no recibido']);
    exit;
}

$nombre = basename($_FILES['archivo']['name']);
$nombre = preg_replace('/[^a-zA-Z0-9._-]/', '_', $nombre); // sanitizar
move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta . $nombre);
echo json_encode(['ok' => true]);
?>