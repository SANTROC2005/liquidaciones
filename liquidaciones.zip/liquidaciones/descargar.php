<?php
require_once 'auth.php';

if (!usuarioAutenticado()) {
    http_response_code(403);
    exit('No autenticado');
}

$usuario = $_SESSION['usuario'];
$archivo = basename($_GET['archivo'] ?? '');
$ruta = __DIR__ . "/usuarios/$usuario/$archivo";

if (!file_exists($ruta) || !preg_match('/\.zip$/', $archivo)) {
    http_response_code(404);
    exit('Archivo no encontrado');
}

header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $archivo . '"');
readfile($ruta);
exit;
?>