<?php
require_once 'auth.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$nombre      = trim($input['nombre'] ?? '');
$apellidos   = trim($input['apellidos'] ?? '');
$email       = trim($input['email'] ?? '');
$usuario     = trim($input['usuario'] ?? '');
$contrasena  = $input['contrasena'] ?? '';

// Validaciones
if (strlen($nombre) < 1 || strlen($apellidos) < 1) {
    http_response_code(400);
    echo json_encode(['error' => 'Nombre y apellidos son obligatorios']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email inválido']);
    exit;
}
if (strlen($usuario) < 3) {
    http_response_code(400);
    echo json_encode(['error' => 'Usuario debe tener al menos 3 caracteres']);
    exit;
}
if (strlen($contrasena) < 6) {
    http_response_code(400);
    echo json_encode(['error' => 'Contraseña debe tener al menos 6 caracteres']);
    exit;
}

// Intentar crear usuario
$result = crearUsuarioCompleto($usuario, $contrasena, [
    'nombre' => $nombre,
    'apellidos' => $apellidos,
    'email' => $email,
    'usuario' => $usuario
]);

if ($result === true) {
    echo json_encode(['ok' => true]);
} else {
    http_response_code(409);
    echo json_encode(['error' => $result]); // mensaje de error personalizado
}
?>