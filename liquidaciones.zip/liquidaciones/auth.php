<?php
session_start();

function usuarioAutenticado() {
    return isset($_SESSION['usuario']);
}

function verificarUsuario($usuario, $contrasena) {
    $ruta = __DIR__ . "/usuarios/$usuario/credenciales.json";
    if (!file_exists($ruta)) return false;
    $datos = json_decode(file_get_contents($ruta), true);
    return password_verify($contrasena, $datos['contrasena']);
}

function crearUsuarioCompleto($usuario, $contrasena, $perfil) {
    $carpeta = __DIR__ . "/usuarios/$usuario";
    if (file_exists($carpeta)) {
        return 'Usuario ya existe';
    }

    // Validar que no haya otro usuario con el mismo email
    $usuariosDir = __DIR__ . '/usuarios';
    if (is_dir($usuariosDir)) {
        foreach (scandir($usuariosDir) as $subdir) {
            if ($subdir === '.' || $subdir === '..') continue;
            $perfilPath = "$usuariosDir/$subdir/perfil.json";
            if (file_exists($perfilPath)) {
                $datos = json_decode(file_get_contents($perfilPath), true);
                if (isset($datos['email']) && $datos['email'] === $perfil['email']) {
                    return 'Ya existe un usuario con ese email';
                }
            }
        }
    }

    mkdir($carpeta, 0700, true);

    // Guardar credenciales (solo hash)
    $hash = password_hash($contrasena, PASSWORD_DEFAULT);
    file_put_contents("$carpeta/credenciales.json", json_encode(['contrasena' => $hash]));

    // Guardar perfil (sin contraseña)
    unset($perfil['contrasena']);
    file_put_contents("$carpeta/perfil.json", json_encode($perfil, JSON_PRETTY_PRINT));

    return true;
}
?>