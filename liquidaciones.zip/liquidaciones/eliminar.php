<?php
session_start();

// Verificar autenticación
if (!isset($_SESSION['usuario'])) {
    http_response_code(403);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

$usuario = $_SESSION['usuario'];
$rutaBase = __DIR__ . '/usuarios/' . $usuario . '/';

// Asegurar que la carpeta del usuario existe
if (!is_dir($rutaBase)) {
    http_response_code(404);
    echo json_encode(['error' => 'Carpeta de usuario no encontrada']);
    exit;
}

// Obtener el nombre del archivo desde la URL
if (!isset($_GET['archivo']) || empty($_GET['archivo'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Nombre de archivo no especificado']);
    exit;
}

$archivo = $_GET['archivo'];

// Validar nombre del archivo: solo permitir letras, números, guiones, guiones bajos y .zip
if (!preg_match('/^[a-zA-Z0-9._\-]+\.zip$/', $archivo)) {
    http_response_code(400);
    echo json_encode(['error' => 'Nombre de archivo no válido']);
    exit;
}

$rutaCompleta = $rutaBase . $archivo;

// Verificar que el archivo exista
if (!file_exists($rutaCompleta)) {
    http_response_code(404);
    echo json_encode(['error' => 'Archivo no encontrado']);
    exit;
}

// Intentar eliminar
if (unlink($rutaCompleta)) {
    http_response_code(200);
    echo json_encode(['mensaje' => 'Archivo eliminado correctamente']);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'No se pudo eliminar el archivo']);
}
?>