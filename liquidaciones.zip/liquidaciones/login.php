<?php
require_once 'auth.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Verificación de sesión activa
    if (usuarioAutenticado()) {
        echo json_encode(['autenticado' => true]);
    } else {
        http_response_code(401);
    }
    exit;
}

// Manejo normal de login (POST)
$input = json_decode(file_get_contents('php://input'), true);

if (verificarUsuario($input['usuario'] ?? '', $input['contrasena'] ?? '')) {
    $_SESSION['usuario'] = $input['usuario'];

    // --- NUEVO CÓDIGO PARA LEER EL PERFIL DEL USUARIO ---
    $usuario = $input['usuario'];
    $rutaPerfil = __DIR__ . "/usuarios/{$usuario}/perfil.json"; // Construye la ruta absoluta

    $datosPerfil = [
        'nombre' => '',
        'apellidos' => ''
    ];

    if (file_exists($rutaPerfil)) {
        $contenido = file_get_contents($rutaPerfil);
        $datosPerfil = json_decode($contenido, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Si hay error al decodificar JSON, reseteamos los datos
            $datosPerfil = ['nombre' => '', 'apellidos' => ''];
        }
    }

    // Devolvemos los datos del perfil junto con la confirmación de éxito
    echo json_encode([
        'ok' => true,
        'nombre' => $datosPerfil['nombre'],
        'apellidos' => $datosPerfil['apellidos']
    ]);
    // --- FIN DEL NUEVO CÓDIGO ---

} else {
    http_response_code(401);
    echo json_encode(['error' => 'Credenciales incorrectas']);
}
?>